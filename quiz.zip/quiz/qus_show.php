<?php
include("class/user.php");
$cat=$_POST["cat"];
$obj->qus_show($cat);
$_SESSION["cat"]=$cat;
?>
<form method="post" action="answer.php">
	<?php
	foreach($obj->qus as $qust)
	{
	?>
	<table>
		<tr>
			<th><?php echo $qust["question"]; ?></th>
		</tr>
		<tr>
			<td><input type="radio" value="0" name="<?php echo $qust["id"]; ?>"> <?php echo $qust["ans1"]; ?> </td>
		</tr>

		<tr>
			<td><input type="radio" value="0" name="<?php echo $qust["id"]; ?>"> <?php echo $qust["ans2"]; ?> </td>
		</tr>

		<tr>
			<td><input type="radio" value="0" name="<?php echo $qust["id"]; ?>"> <?php echo $qust["ans3"]; ?> </td>
		</tr>

		<tr>
			<td><input type="radio" value="0" name="<?php echo $qust["id"]; ?>"> <?php echo $qust["ans4"]; ?> </td>
		</tr>
		<tr>
			<td><input type="radio" value="no_attemp" checked="checked" style="display: none;" name="<?php echo $qust["id"]; ?>"></td>
		</tr>
	</table>


	<?php
	}

	?>
	<input type="submit" value="Submit">
</form>
	
