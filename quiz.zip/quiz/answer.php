<?php
include("class/user.php");
extract($_POST);
$obj->answer($_POST);
//print_r($_POST);

?>