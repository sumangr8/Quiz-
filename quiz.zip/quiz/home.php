<?php
include("class/user.php");
$email=$_SESSION["email"];
$obj->profile($email);
$obj->category();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<br>

<div class="container">
  <h2>online Quiz </h2>
  <br>
  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" data-toggle="tab" href="#home">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#menu1">Profile</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#menu2">Logout</a>
    </li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div id="home" class="container tab-pane active"><br>
      <h3>HOME</h3>
      <center>
        <form method="post" action="qus_show.php">
          <select name="cat">
            <option>Select</option>
            <?php
            foreach($obj->cat as $cate)
            {
            ?>
            <option value="<?php echo $cate["id"]; ?>"><?php echo $cate["cat_name"]; ?></option>
            <?php
            }
            ?>
          </select><br><br>
          <input type="submit" value="Start" class="btn btn-primary">
      </form>
      </center>
    </div>
    <div id="menu1" class="container tab-pane fade"><br>
      <h3>Profile</h3>
      <p>Show Profile</p>
      <table class="table">
        <tr>
          <td>Name</td>
          <td>Email</td>
        </tr>
        <tr>
        <?php
        foreach($obj->data as $prof)
        {
        ?>
        <td><?php echo $prof["name"]; ?></td>
        <td><?php echo $prof["email"]; ?></td>
        <?php
        }
        ?>
      </tr>
      </table>
    </div>
    <div id="menu2" class="container tab-pane fade"><br>
      <h3>Logout</h3>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
    </div>
  </div>
</div>

</body>
</html>
