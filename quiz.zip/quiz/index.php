<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
	<form method="post" action="signin_sub.php" style="float: left; width: 40%;">
		<h2>
			<?php
			if(isset($_GET["login"]))
			{
				echo "Login faield";
			}
			?>
		</h2>
	  <div class="form-group">
	    <label for="email">Email address:</label>
	    <input type="email" class="form-control" name="email" placeholder="Enter email" id="email">
	  </div>
	  <div class="form-group">
	    <label for="pwd">Password:</label>
	    <input type="password" class="form-control" name="pass" placeholder="Enter password" id="pwd">
	  </div>
	  <button type="submit" class="btn btn-primary" name="l">Login</button>
	</form>



	<form method="post" action="signup_sub.php" enctype="multipart/form-data" style="float: right; width: 40%;">
		<h2>
			<?php
			if(isset($_GET["run"]))
			{
				echo "Insert Sucess";
			}
			?>
		</h2>
	  <div class="form-group">
	    <label for="email">Name:</label>
	    <input type="text" class="form-control" name="name" placeholder="Enter email" id="email">
	  </div>
	  <div class="form-group">
	    <label for="email">Email address:</label>
	    <input type="email" class="form-control" name="email" placeholder="Enter email" id="email">
	  </div>
	  <div class="form-group">
	    <label for="pwd">Password:</label>
	    <input type="password" class="form-control" name="pass" placeholder="Enter password" id="pwd">
	  </div>
	  	<div class="form-group">
	    <label for="email">Pic:</label>
	    <input type="file" class="form-control" name="img" placeholder="Enter email" id="email">
	  </div>
	  <button type="submit" class="btn btn-primary" name="i">Signup</button>
	</form>
</div>
</body>
</html>