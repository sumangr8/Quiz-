<!-- For Insert -->
<?php
include("class/user.php");
extract($_POST);
if(isset($_POST["i"]))
{
	$img=$_FILES["img"]["tmp_name"];
	$destination="img/".$_FILES["img"]["name"];
	if(move_uploaded_file($img, $destination))
	{
		$img=$_FILES["img"]["name"];
	}

	//$obj->insert($name,$email,$pass,$img);
	if($obj->insert($name,$email,$pass,$img))
	{
		header("location:index.php?run=sucess");
	}
	else
	{
		header("location:index.php?error=err");
	}
}


?>