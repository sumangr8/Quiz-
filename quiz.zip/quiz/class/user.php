<?php
session_start();
class user
{
	public $host="localhost";
	public $username="root";
	public $password="";
	public $db="quiz_oops";
	public $conn;
	public $data;
	public $cat;
	public $qus;

	public function __construct()
	{
		$this->conn=new mysqli($this->host,$this->username,$this->password,$this->db);
	}


	public function insert($name,$email,$pass,$img)
	{
		$qry=$this->conn->query("insert into signup values('','$name','$email','$pass','$img')");
		if($qry)
		{
			return true;
		}
		else
		{
			return false;
		}
	}


	public function login($email,$pass)
	{
		$qry=$this->conn->query("select * from signup where email='$email' and pass='$pass'");
		$row=$qry->fetch_array(MYSQLI_ASSOC);
		if($qry->num_rows>0)
		{
			$_SESSION["email"]=$email;
			return true;
		}
		else
		{
			return false;
		}
	}


	public function profile($email)
	{
		$qry=$this->conn->query("select * from signup where email='$email'");
		while($row=$qry->fetch_array(MYSQLI_ASSOC))
		{
			$this->data[]=$row;
		}
		return $this->data;
	}


	public function category()
	{
		$qry=$this->conn->query("select * from category");
		while($row=$qry->fetch_array(MYSQLI_ASSOC))
		{
			$this->cat[]=$row;
		}
		return $this->cat;
	}


	public function qus_show($cat)
	{
		$qry=$this->conn->query("select * from questions where cat_id='$cat'");
		while($row=$qry->fetch_array(MYSQLI_ASSOC))
		{
			$this->qus[]=$row;
		}
		return $this->qus;
	}


	public function answer($data)
	{
		$data=implode("", $data);
		$right=0;
		$wrong=0;
		$no_answer=0;
		$qry=$this->conn->query("select * from questions where cat_id='".$_SESSION["cat"]."'");
		while($qust=$qry->fetch_array(MYSQLI_ASSOC))
		{
			if($qust["ans"]==$_POST[$qust["id"]])
			{
				$right++;
			}
			elseif($_POST[$qust["id"]]=="no_attemp")
			{
				$no_answer++;
			}
			else
			{
				$wrong++;
			}
		}

		echo "Right".$right;
		echo "No Answer".$no_answer;
		echo "Wrong".$wrong;
	}
}
$obj=new user;

?>