<!-- For Login -->
<?php
include("class/user.php");
extract($_POST);
if(isset($_POST["l"]))
{
	//$obj->login($email,$pass);
	if($obj->login($email,$pass))
	{
		header("location:home.php");
	}
}


?>